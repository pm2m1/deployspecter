def finish(job):
    claim_guard(job)
    update(job)
