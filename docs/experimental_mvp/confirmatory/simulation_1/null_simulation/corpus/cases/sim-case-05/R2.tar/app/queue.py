def finish(job):
    update(job)
