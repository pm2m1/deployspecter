# Upgrading

Stop the workers, run the migrations, start the new workers.
