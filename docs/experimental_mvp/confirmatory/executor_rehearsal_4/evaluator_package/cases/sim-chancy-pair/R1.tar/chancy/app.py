import asyncio
import datetime
import enum
import functools
import logging
from collections.abc import AsyncGenerator, Iterable, Iterator
from functools import cache, cached_property
from typing import Any

from psycopg import AsyncCursor, Cursor, sql
from psycopg.rows import DictRow, dict_row
from psycopg.types.json import Json
from psycopg_pool import AsyncConnectionPool, ConnectionPool

from chancy.job import IsAJob, Job, QueuedJob, Reference
from chancy.migrate import Migrator
from chancy.plugin import Plugin
from chancy.queue import Queue
from chancy.utils import (
    DatabaseConnection,
    chancy_uuid,
    chunked,
    get_database_dsn,
    json_dumps,
    lock_order_key,
)


@cache
def setup_default_logger(level: int = logging.INFO):
    """
    Set up the default logger for the application.

    This method will configure the logger for the application, setting the
    log level and adding a stream handler to log to the console.

    :param level: The log level to set on the logger. Defaults to DEBUG.
    """
    logger = logging.getLogger("chancy")
    logger.setLevel(level)

    if logger.handlers:
        return logger

    try:
        from rich.logging import RichHandler

        handler = RichHandler()
    except ImportError:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                fmt="[%(asctime)s][%(levelname)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )

    logger.handlers[:] = [handler]
    return logger


class Chancy:
    """
    A Chancy application, along with all of its configuration and common
    functionality.

    Chancy is asyncio-first, and all of its methods are async by default:

    .. code-block:: python

        import asyncio
        from chancy import Chancy, Job, Queue

        def my_job():
            print("Hello, world!")

        async def main():
            async with Chancy("postgresql://localhost/chancy") as chancy:
                await chancy.migrate()
                await chancy.declare(Queue("default"))
                await chancy.push(Job.from_func(my_job))

        asyncio.run(main())

    Chancy does also provide a minimal synchronous interface for pushing jobs
    onto the queue for codebases that are not using asyncio:

    .. code-block:: python

        from chancy import Chancy, Job, Queue

        def my_job():
            print("Hello, world!")

        with Chancy("postgresql://localhost/chancy") as chancy:
            chancy.sync_push(Job.from_func(my_job))

    And of course, it's just Postgres under the hood, so you can always just
    insert jobs directly into the database if you're feeling brave.

    :param dsn: The DSN to connect to the database.
    :param plugins: The plugins to use with the application.
    :param prefix: A prefix appended to all table names, which can be used to
        namespace the tables for multiple applications or tenants.
    :param min_connection_pool_size: The minimum number of connections to keep
        in the pool.
    :param max_connection_pool_size: The maximum number of connections to keep
        in the pool.
    :param poll_reconnect_timeout: The number of seconds to wait before
        attempting to reconnect to the database if a connection is lost.
    :param notifications: Enables or disables emitting notifications using
        postgres's NOTIFY/LISTEN feature.
    :param log: The logger to use for all application logging. If not provided,
        a default logger will be set up.
    :param no_default_plugins: If `True`, the default plugins will not be
        enabled. Defaults to `False`.
    """

    class Executor(enum.StrEnum):
        """
        Shortcuts for the built-in executors.
        """

        #: The default executor, which runs jobs in a process pool.
        Process = "chancy.executors.process.ProcessExecutor"
        #: The threaded executor, which runs jobs in a thread pool.
        Threaded = "chancy.executors.thread.ThreadedExecutor"
        #: The asyncio executor, which runs jobs in an asyncio event loop.
        Async = "chancy.executors.asyncex.AsyncExecutor"
        #: The subprocess executor, which runs jobs in an experimental
        #: subinterpreter.
        SubInterpreter = "chancy.executors.sub.SubInterpreterExecutor"

    @staticmethod
    def _ensure_pool_is_open(f):
        """
        A decorator which ensures the connection pool is open before calling
        the wrapped function.

        It's never ideal to rely on this, since it will never _close_ the pool,
        but users expect to be able to just call push() and have it work.
        """

        @functools.wraps(f)
        async def wrapper(self, *args, **kwargs):
            await self.pool.open()
            return await f(self, *args, **kwargs)

        return wrapper

    @staticmethod
    def _ensure_sync_pool_is_open(f):
        """
        A decorator which ensures the connection pool is open before calling
        the wrapped function.

        It's never ideal to rely on this, since it will never _close_ the pool,
        but users expect to be able to just call push() and have it work.
        """

        @functools.wraps(f)
        def wrapper(self, *args, **kwargs):
            self.sync_pool.open()
            return f(self, *args, **kwargs)

        return wrapper

    @staticmethod
    def _ensure_pool_is_open_async_iter(f):
        """
        A decorator which ensures the connection pool is open before calling
        the wrapped function.

        It's never ideal to rely on this, since it will never _close_ the pool,
        but users expect to be able to just call push() and have it work.
        """

        @functools.wraps(f)
        async def wrapper(self, *args, **kwargs):
            await self.pool.open()
            async for record in f(self, *args, **kwargs):
                yield record

        return wrapper

    def __init__(
        self,
        dsn: str | DatabaseConnection,
        *,
        plugins: list[Plugin] | None = None,
        prefix: str = "chancy_",
        min_connection_pool_size: int = 1,
        max_connection_pool_size: int = 10,
        poll_reconnect_timeout: int = 60 * 5,
        notifications: bool = True,
        log: logging.Logger | None = None,
        no_default_plugins: bool = False,
    ):
        #: The DSN to connect to the database.
        self.dsn = dsn if isinstance(dsn, str) else get_database_dsn(dsn)
        #: The plugins to use with the application.
        self.plugins = {}
        #: A prefix appended to all table names, which can be used to
        #: namespace the tables for multiple applications or tenants.
        self.prefix = prefix
        #: The minimum number of connections to keep in the pool.
        self.min_connection_pool_size = min_connection_pool_size
        #: The maximum number of connections to keep in the pool.
        self.max_connection_pool_size = max_connection_pool_size
        #: The number of seconds to wait before attempting to reconnect to the
        #: database if a connection is lost.
        self.poll_reconnect_timeout = poll_reconnect_timeout
        #: Enables or disables emitting notifications using postgres's
        #: NOTIFY/LISTEN feature.
        self.notifications = notifications
        #: The logger to use for all application logging.
        self.log = log or setup_default_logger()

        for plugin in plugins or []:
            if (identifier := plugin.get_identifier()) in self.plugins:
                other_type = type(self.plugins[identifier])
                if isinstance(plugin, other_type):
                    raise ValueError(
                        f"Duplicate plugin of type {type(plugin)!r} with"
                        f" identifier {identifier!r}."
                    )
                else:
                    raise ValueError(
                        f"The plugin of type {type(plugin)!r} has the same"
                        f" identifier {identifier!r} which conflicts with"
                        f" another plugin of type {other_type}."
                    )

            self.plugins[identifier] = plugin

        if not no_default_plugins:
            # If the user hasn't specified otherwise, well enable some common
            # default plugins with reasonable defaults.
            defaults = {
                Leadership.get_identifier(): lambda: Leadership(),
                Pruner.get_identifier(): lambda: Pruner(),
                Recovery.get_identifier(): lambda: Recovery(),
                Metrics.get_identifier(): lambda: Metrics(),
                WorkflowPlugin.get_identifier(): lambda: WorkflowPlugin(),
            }

            for identifier, plugin in defaults.items():
                if identifier not in self.plugins:
                    self.plugins[identifier] = p = plugin()
                    self.log.debug(
                        f"Enabled default plugin {p.__class__.__name__!r},"
                        f" providing {identifier!r}."
                    )

    async def __aenter__(self):
        await self.pool.open()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.pool.close()
        del self.pool

    def __enter__(self):
        self.sync_pool.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.sync_pool.close()
        del self.sync_pool
        return False

    @cached_property
    def pool(self) -> AsyncConnectionPool:
        """
        The asyncio connection pool used to interact with the database.
        """
        return AsyncConnectionPool(
            self.dsn,
            min_size=self.min_connection_pool_size,
            max_size=self.max_connection_pool_size,
            reconnect_timeout=self.poll_reconnect_timeout,
            # Opening the pool here is deprecated, and should be done
            # explicitly by the user with a context manager or open/close.
            open=False,
        )

    @cached_property
    def sync_pool(self) -> ConnectionPool:
        """
        The synchronous connection pool used to interact with the database.
        """
        return ConnectionPool(
            self.dsn,
            min_size=self.min_connection_pool_size,
            max_size=self.max_connection_pool_size,
            reconnect_timeout=self.poll_reconnect_timeout,
            # Opening the pool here is deprecated, and should be done
            # explicitly by the user with a context manager or open/close.
            open=False,
        )

    @_ensure_pool_is_open
    async def migrate(self, *, to_version: int | None = None):
        """
        Migrate the database to the latest version.

        This will migrate the core database tables as well as any enabled
        plugins. If a version is provided, the database will be migrated up
        _or_ down to that version as necessary.

        .. code-block:: python

            async with Chancy("postgresql://localhost/chancy") as chancy:
                await chancy.migrate()

        Can also be run with the CLI:

        .. code-block:: bash

            chancy --app worker.chancy misc migrate

        .. warning::

            You should never run migrations in production without first testing
            them in a development environment. Migrations can be destructive and
            may cause data loss if not written carefully, or take a long time to
            complete if the database is large.

        :param to_version: The version to migrate to. If not provided, the
            database will be migrated to the latest version.
        """
        migrator = Migrator("chancy", "chancy.migrations", prefix=self.prefix)
        async with self.pool.connection() as conn:
            await migrator.migrate(conn, to_version=to_version)

        for plugin in self.plugins.values():
            await plugin.migrate(self, to_version=to_version)

    @_ensure_pool_is_open
    async def is_up_to_date(self) -> bool:
        """
        Check if the database is up to date.

        This will check if the database schema is up to date with the latest
        available migrations. If the database is up to date, returns `True`.
        """
        migrator = Migrator("chancy", "chancy.migrations", prefix=self.prefix)
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            if await migrator.is_migration_required(cursor):
                return False

            for plugin in self.plugins.values():
                migrator = plugin.migrator(self)
                if migrator is None:
                    continue
                if await migrator.is_migration_required(cursor):
                    return False

        return True

    @_ensure_pool_is_open
    async def declare(self, queue: Queue, *, upsert: bool = False) -> Queue:
        """
        Declare a queue in the database.

        Queues in Chancy are the primary mechanism for organizing and
        executing jobs. They can be configured with various options to
        control how jobs are processed, including the concurrency level,
        rate limiting, and tags to restrict which workers can process jobs
        from the queue.

        Queues exist globally, configured at runtime via the database and
        can be updated, reassigned, or deleted at any time without requiring
        a restart of the workers.

        This will create a new queue in the database with the provided
        configuration. If the queue already exists, no changes will be
        made unless the ``upsert`` parameter is also set to ``True``.

        .. code-block:: python

            async with Chancy("postgresql://localhost/chancy") as chancy:
                await chancy.declare(Queue("default"))

        .. seealso::

            :meth:`sync_declare` for a synchronous version of this method.

        :param queue: The queue to declare.
        :param upsert: If `True`, the queue will be updated if it already
            exists. Defaults to `False`.
        :return: The queue as it exists in the database.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            queue = await self.declare_ex(cursor, queue, upsert=upsert)
            await self.notify(cursor, "queue.declared", {"q": queue.name})
            return queue

    @_ensure_sync_pool_is_open
    def sync_declare(self, queue: Queue, *, upsert: bool = False) -> Queue:
        """
        Synchronously declare a queue in the database. See :func:`declare` for
        more information.

        .. code-block:: python

            with Chancy("postgresql://localhost/chancy") as chancy:
                chancy.sync_declare(Queue("default"))

        .. seealso::

            :meth:`declare` for an asynchronous version of this method.

        :param queue: The queue to declare.
        :param upsert: If `True`, the queue will be updated if it already
            exists. Defaults to `False`.
        :return: The queue as it exists in the database.
        """
        with (
            self.sync_pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            queue = self.sync_declare_ex(cursor, queue, upsert=upsert)
            self.sync_notify(cursor, "queue.declared", {"q": queue.name})
            return queue

    async def declare_ex(
        self,
        cursor: AsyncCursor[DictRow],
        queue: Queue,
        *,
        upsert: bool = False,
    ) -> Queue:
        """
        Declare a queue in the database using a specific cursor.

        This is a low-level method that allows for more control over the
        database connection and transaction management. It is recommended to
        use the higher-level `declare` method in most cases.

        :param cursor: The cursor to use for the operation.
        :param queue: The queue to declare.
        :param upsert: If `True`, the queue will be updated if it already
            exists. Defaults to `False`.
        """
        await cursor.execute(
            self._declare_sql(upsert),
            {
                "name": queue.name,
                "state": queue.state.value,
                "concurrency": queue.concurrency,
                "tags": list(queue.tags),
                "executor": queue.executor,
                "executor_options": Json(queue.executor_options),
                "polling_interval": queue.polling_interval,
                "rate_limit": queue.rate_limit,
                "rate_limit_window": queue.rate_limit_window,
                "resume_at": queue.resume_at,
                "eager_polling": queue.eager_polling,
            },
        )

        result = await cursor.fetchone()
        return Queue(
            **{
                **result,
                "name": queue.name,
                "tags": set(result["tags"]),
                "state": Queue.State(result["state"]),
            }
        )

    def sync_declare_ex(
        self,
        cursor: Cursor[DictRow],
        queue: Queue,
        *,
        upsert: bool = False,
    ) -> Queue:
        """
        Synchronously declare a queue in the database using a specific cursor.
        See :func:`declare_ex` for more information.

        .. seealso::

            :meth:`declare_ex` for an asynchronous version of this method.
        """
        cursor.execute(
            self._declare_sql(upsert),
            {
                "name": queue.name,
                "state": queue.state.value,
                "concurrency": queue.concurrency,
                "tags": list(queue.tags),
                "executor": queue.executor,
                "executor_options": Json(queue.executor_options),
                "polling_interval": queue.polling_interval,
                "rate_limit": queue.rate_limit,
                "rate_limit_window": queue.rate_limit_window,
                "resume_at": queue.resume_at,
                "eager_polling": queue.eager_polling,
            },
        )

        result = cursor.fetchone()
        return Queue(
            **{
                **result,
                "name": queue.name,
                "tags": set(result["tags"]),
                "state": Queue.State(result["state"]),
            }
        )

    @_ensure_pool_is_open
    async def push(self, job: Job | IsAJob[..., Any]) -> Reference:
        """
        Push a job onto the queue.

        This method will push a job onto the queue, making it available for
        processing by workers. A :class:`Reference` object is returned that
        can be used to track the progress of the job and retrieve the result
        when it is complete.

        .. code-block:: python

            from chancy import Chancy, Job

            @job()
            def my_job():
                print("Hello, world!")

            async with Chancy("postgresql://localhost/chancy") as chancy:
                await chancy.push(my_job)

        .. seealso::

            :meth:`sync_push` for a synchronous version of this method.

        :param job: The job to push onto the queue.
        :return: A reference to the job in the queue.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            return (await self.push_many_ex(cursor, [job]))[0]

    @_ensure_pool_is_open
    async def push_ex(
        self, cursor: AsyncCursor, job: Job | IsAJob[..., Any]
    ) -> Reference:
        """
        Push a job onto the queue using a specific cursor.

        This is a low-level method that allows for more control over the
        database connection and transaction management. It is recommended to
        use the higher-level `push` method in most cases.

        :param cursor: The cursor to use for the operation.
        :param job: The job to push onto the queue.
        :return: A reference to the job in the queue.
        """
        return (await self.push_many_ex(cursor, [job]))[0]

    @_ensure_sync_pool_is_open
    def sync_push(self, job: Job) -> Reference:
        """
        Synchronously push a job onto the queue.

        This method provides a synchronous interface to push a job onto the
        queue.

        .. code-block:: python

            from chancy import Chancy, Job

            @job()
            def my_job():
                print("Hello, world!")

            with Chancy("postgresql://localhost/chancy") as chancy:
                chancy.sync_push(my_job)

        .. seealso::

            :meth:`push` for an asynchronous version of this method.

        :param job: The job to push onto the queue.
        :return: A reference to the job in the queue.
        """
        with (
            self.sync_pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            return self.sync_push_many_ex(cursor, [job])[0]

    @_ensure_pool_is_open_async_iter
    async def push_many(
        self, jobs: list[Job], *, batch_size: int = 1000
    ) -> AsyncGenerator[list[Reference], None]:
        """
        Push multiple jobs onto the queue.

        This method will push multiple jobs onto the queue, making them
        available for processing by workers. Jobs are committed in batches,
        with the size of each batch controlled by the `batch_size` parameter.
        Each batch is committed within its own transaction to limit peak
        memory usage.

        Returns an iterator of lists of references to the jobs in the queue,
        one list per batch:

        .. code-block:: python

            async for references in chancy.push_many(jobs):
                print(references)

        .. seealso::

            :meth:`sync_push_many` for a synchronous version of this method.

        :param jobs: The jobs to push onto the queue.
        :param batch_size: The number of jobs to push in each batch. Defaults
            to 1000.
        :return: An iterator of lists of references to the jobs in the queue.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            for chunk in chunked(jobs, batch_size):
                async with conn.transaction():
                    yield await self.push_many_ex(cursor, chunk)

    @_ensure_sync_pool_is_open
    def sync_push_many(
        self, jobs: list[Job | IsAJob[..., Any]], *, batch_size: int = 1000
    ) -> Iterator[list[Reference]]:
        """
        Synchronously push multiple jobs onto the queue.

        This method provides a synchronous interface to push multiple jobs onto
        the queue.

        Returns an iterator of lists of references to the jobs in the queue,
        one list per batch.

        .. seealso::

            :meth:`push_many` for an asynchronous version of this method.

        :param jobs: The jobs to push onto the queue.
        :param batch_size: The number of jobs to push in each batch. Defaults
            to 1000.
        :return: An iterator of lists of references to the jobs in the queue.
        """
        with (
            self.sync_pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            for chunk in chunked(jobs, batch_size):
                with conn.transaction():
                    yield self.sync_push_many_ex(cursor, chunk)

    async def push_many_ex(
        self, cursor: AsyncCursor[DictRow], jobs: list[Job | IsAJob[..., Any]]
    ) -> list[Reference]:
        """
        Push multiple jobs onto the queue using a specific cursor.

        This is a low-level method that allows for more control over the
        database connection and transaction management. It is recommended to
        use the higher-level `push_many` method in most cases.

        The main advantage of using this function is to ensure your jobs are
        only pushed if some other operation is successful. For example, you
        only want to send an email confirmation if account creation actually
        succeeds. For example:

        .. seealso::

            :meth:`sync_push_many_ex` for a synchronous version of this method.

        :param cursor: The cursor to use for the operation.
        :param jobs: The jobs to push onto the queue.
        :return: A list of references to the jobs in the queue.
        """
        # Jobs are inserted in unique_key order so that concurrent pushes and
        # the worker's batched job updates (which sort the same way) always
        # acquire row locks in the same order and cannot deadlock (#89).
        references: list[Reference | None] = [None] * len(jobs)
        for index, job in self._in_lock_order(jobs):
            await cursor.execute(
                self._push_job_sql(),
                self._get_job_params(job),
            )
            record = await cursor.fetchone()
            references[index] = Reference(record["id"])

        if self.notifications:
            for queue in {
                job.queue if isinstance(job, Job) else job.job.queue
                for job in jobs
            }:
                await self.notify(cursor, "queue.pushed", {"q": queue})

        return references

    def sync_push_many_ex(
        self, cursor: Cursor, jobs: list[Job]
    ) -> list[Reference]:
        """
        Synchronously push multiple jobs onto the queue using a specific cursor.

        This is a low-level method that allows for more control over the
        database connection and transaction management. It is recommended to
        use the higher-level `sync_push_many` method in most cases.

        .. seealso::

            :meth:`push_many_ex` for an asynchronous version of this method.

        :param cursor: The cursor to use for the operation.
        :param jobs: The jobs to push onto the queue.
        :return: A list of references to the jobs in the queue.
        """
        # See push_many_ex for why jobs are inserted in unique_key order.
        references: list[Reference | None] = [None] * len(jobs)
        for index, job in self._in_lock_order(jobs):
            cursor.execute(
                self._push_job_sql(),
                self._get_job_params(job),
            )
            record = cursor.fetchone()
            references[index] = Reference(record["id"])

        for queue in {job.queue for job in jobs}:
            self.sync_notify(cursor, "queue.pushed", {"q": queue})

        return references

    @_ensure_pool_is_open
    async def get_job(self, ref: Reference) -> QueuedJob | None:
        """
        Resolve a reference to a job instance.

        If the job no longer exists, returns ``None``.

        :param ref: The reference to the job to retrieve.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await cursor.execute(self._get_job_sql(), [ref.identifier])
            record = await cursor.fetchone()
            if record is None:
                return None
            return QueuedJob.unpack(record)

    @_ensure_pool_is_open
    async def get_jobs(self, refs: list[Reference]) -> list[QueuedJob]:
        """
        Resolve multiple references to job instances.

        If a job no longer exists, it will be skipped and not included in
        the returned list.

        :param refs: The references to the jobs to retrieve.
        :return: A list of the resolved jobs.
        """
        if not refs:
            return []

        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await cursor.execute(
                self._get_jobs_sql(), [[ref.identifier for ref in refs]]
            )
            return [
                QueuedJob.unpack(record)
                async for record in cursor
                if record is not None
            ]

    @_ensure_sync_pool_is_open
    def sync_get_job(self, ref: Reference) -> QueuedJob | None:
        """
        Synchronously resolve a reference to a job instance.

        If the job no longer exists, returns ``None``.

        :param ref: The reference to the job to retrieve.
        """
        with (
            self.sync_pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            cursor.execute(self._get_job_sql(), [ref.identifier])
            record = cursor.fetchone()
            if record is None:
                return None
            return QueuedJob.unpack(record)

    async def wait_for_job(
        self,
        ref: Reference,
        *,
        interval: int = 1,
        timeout: float | None = None,
        states: set[QueuedJob.State] | None = None,
    ) -> QueuedJob | None:
        """
        Wait for a job to complete.

        This method will loop until the job referenced by the provided
        reference has completed. The interval parameter controls how often
        the job status is checked. This will not block the event loop, so
        other tasks can run while waiting for the job to complete.

        If the job no longer exists, returns ``None``.

        :param ref: The reference to the job to wait for.
        :param interval: The number of seconds to wait between checks.
        :param timeout: The maximum number of seconds to wait for the job to
            complete. If not provided, the method will wait indefinitely.
        :param states: A set of additional states to consider as "complete". If
            the job enters any of these states, it will be considered complete
            and the method will return. By default, only the SUCCEEDED and
            FAILED states are considered complete.
        """
        states = states or {QueuedJob.State.SUCCEEDED, QueuedJob.State.FAILED}
        async with asyncio.timeout(timeout):
            while True:
                job = await self.get_job(ref)
                if job is None or job.state in states:
                    return job
                await asyncio.sleep(interval)

    async def wait_for_jobs(
        self,
        refs: list[Reference],
        *,
        interval: int = 1,
        timeout: float | None = None,
        states: set[QueuedJob.State] | None = None,
    ):
        """
        Wait for multiple jobs to complete.

        This method will loop until all jobs referenced by the provided
        references have completed. The interval parameter controls how often
        the job status is checked. This will not block the event loop, so
        other tasks can run while waiting for the jobs to complete.

        If a job no longer exists, it will be skipped and not included in
        the returned list.

        :param refs: The references to the jobs to wait for.
        :param interval: The number of seconds to wait between checks.
        :param timeout: The maximum number of seconds to wait for the jobs to
            complete. If not provided, the method will wait indefinitely.
        :param states: A set of additional states to consider as "complete". If
            a job enters any of these states, it will be considered complete
            and removed from the list of jobs to wait for. By default, only
            the SUCCEEDED and FAILED states are considered complete.
        :return: A list of the completed jobs. Jobs that no longer exist will
            not be included in the list.
        """
        states = states or {QueuedJob.State.SUCCEEDED, QueuedJob.State.FAILED}
        async with asyncio.timeout(timeout):
            pending = set(refs)
            completed = []
            while pending:
                jobs = await self.get_jobs(list(pending))
                pending.intersection_update(Reference(job.id) for job in jobs)
                for job in jobs:
                    if job.state in states:
                        completed.append(job)
                        pending.remove(Reference(job.id))
                if pending:
                    await asyncio.sleep(interval)
            return completed

    @_ensure_pool_is_open
    async def get_all_queues(self) -> list[Queue]:
        """
        Get all queues known to the cluster, regardless of their status
        or if they're assigned to any workers.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await cursor.execute(self._get_all_queues_sql())
            return [Queue.unpack(record) async for record in cursor]

    @_ensure_pool_is_open
    async def get_queue(self, name: str) -> Queue:
        """
        Get a specific queue by name.

        :param name: The name of the queue to retrieve.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await cursor.execute(self._get_queue_sql(), [name])
            record = await cursor.fetchone()
            if record is None:
                raise KeyError(f"Queue {name!r} not found.")
            return Queue.unpack(record)

    @_ensure_pool_is_open
    async def delete_queue(self, name: str, *, purge_jobs: bool = True):
        """
        Delete a queue by name.

        By default, also deletes all jobs in the queue. If you want to keep
        the jobs, set `purge_jobs` to `False`.

        :param name: The name of the queue to delete.
        :param purge_jobs: If `True`, all jobs in the queue will be deleted
            along with the queue. If `False`, the jobs will be left in the
            database.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await self.delete_queue_ex(cursor, name, purge_jobs=purge_jobs)

    @_ensure_pool_is_open
    async def pause_queue(
        self,
        name: str,
        *,
        resume_at: datetime.datetime | datetime.timedelta | None = None,
    ):
        """
        Pause a queue by name.

        This will prevent workers from picking up new jobs from the queue,
        but will not affect jobs that are already running.

        .. note::

            It may take a few seconds for all workers to notice the change.

        :param name: The name of the queue to pause.
        :param resume_at: A datetime at which the queue should automatically
                          resume, or a timedelta from the current time.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            # Normalize timedelta to absolute datetime if needed
            if isinstance(resume_at, datetime.timedelta):
                resume_at = datetime.datetime.now(tz=datetime.UTC) + resume_at
            await self.pause_queue_ex(cursor, name, resume_at=resume_at)
            await self.notify(cursor, "queue.paused", {"q": name})

    @_ensure_pool_is_open
    async def resume_queue(self, name: str):
        """
        Resume a queue by name.

        This will allow workers to pick up new jobs from the queue.

        .. note::

            It may take a few seconds for all workers to notice the change.

        :param name: The name of the queue to resume.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await self.resume_queue_ex(cursor, name)
            await self.notify(cursor, "queue.resumed", {"q": name})

    async def delete_queue_ex(
        self,
        cursor: AsyncCursor[DictRow],
        name: str,
        *,
        purge_jobs: bool = True,
    ) -> int:
        """
        Delete a queue by name using an existing cursor.

        See :meth:`delete_queue` for more information.

        .. seealso::

            :meth:`delete_queue` for a helper that manages the connection and
            transaction.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param name: The name of the queue to delete.
        :param purge_jobs: If ``True``, delete all jobs in the queue as well.
        :return: The number of queues deleted (0 or 1).
        """
        await cursor.execute(
            sql.SQL(
                """
                DELETE FROM {queues}
                WHERE name = %s
                """
            ).format(queues=sql.Identifier(f"{self.prefix}queues")),
            [name],
        )
        if purge_jobs:
            await cursor.execute(
                sql.SQL(
                    """
                    DELETE FROM {jobs}
                    WHERE queue = %s
                    """
                ).format(jobs=sql.Identifier(f"{self.prefix}jobs")),
                [name],
            )
        return cursor.rowcount or 0

    async def pause_queue_ex(
        self,
        cursor: AsyncCursor[DictRow],
        name: str,
        *,
        resume_at: datetime.datetime | None = None,
    ) -> int:
        """
        Pause a queue by name using an existing cursor.

        See :meth:`pause_queue` for more information.

        .. seealso::

            :meth:`pause_queue` for a helper that manages the connection and
            emits notifications.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param name: The name of the queue to pause.
        :param resume_at: An absolute datetime when the queue should
            automatically resume, or ``None`` to require manual resume.
        :return: The number of rows updated.
        """
        await cursor.execute(
            sql.SQL(
                """
                UPDATE {queues}
                SET state = 'paused', resume_at = %(resume_at)s
                WHERE name = %(name)s
                """
            ).format(queues=sql.Identifier(f"{self.prefix}queues")),
            {"name": name, "resume_at": resume_at},
        )
        return cursor.rowcount or 0

    async def resume_queue_ex(
        self, cursor: AsyncCursor[DictRow], name: str
    ) -> int:
        """
        Resume a queue by name using an existing cursor.

        See :meth:`resume_queue` for more information.

        .. seealso::

            :meth:`resume_queue` for a helper that manages the connection and
            emits notifications.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param name: The name of the queue to resume.
        :return: The number of rows updated.
        """
        await cursor.execute(
            sql.SQL(
                """
                UPDATE {queues}
                SET
                    state = 'active',
                    resume_at = NULL
                WHERE name = %(name)s
                """
            ).format(queues=sql.Identifier(f"{self.prefix}queues")),
            {"name": name},
        )
        return cursor.rowcount or 0

    @_ensure_pool_is_open
    async def get_all_workers(self) -> list[dict[str, Any]]:
        """
        Get all workers known to the cluster, regardless of their status.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await cursor.execute(self._get_all_workers_sql())
            return [record async for record in cursor]

    async def notify(
        self, cursor: AsyncCursor[DictRow], event: str, payload: dict[str, Any]
    ):
        """
        Send a notification via Postgres NOTIFY/LISTEN to all other listening
        workers.

        If notifications are disabled on the associated Chancy app, this
        method will do nothing.

        .. seealso::

            :meth:`sync_notify` for a synchronous version of this method.
        """
        await self.notify_many(cursor, [(event, payload)])

    async def notify_many(
        self,
        cursor: AsyncCursor[DictRow],
        events: Iterable[tuple[str, dict[str, Any]]],
    ):
        """
        Send multiple notifications with one SQL statement.

        Each event retains its own payload and is delivered after the caller's
        transaction commits. Empty batches and disabled notifications do no
        database work.

        :param cursor: The cursor for the transaction sending notifications.
        :param events: Pairs of event names and payloads, in delivery order.
        """
        if not self.notifications:
            return
        payloads = [json_dumps({"t": event, **body}) for event, body in events]
        if not payloads:
            return
        await cursor.execute(
            """
            SELECT pg_notify(%s, payload)
            FROM unnest(%s::text[]) WITH ORDINALITY AS events(payload, position)
            ORDER BY position
            """,
            [f"{self.prefix}events", payloads],
        )

    def sync_notify(self, cursor: Cursor, event: str, payload: dict[str, Any]):
        """
        Send a notification via Postgres NOTIFY/LISTEN to all other listening
        workers.

        If notifications are disabled on the associated Chancy app, this
        method will do nothing.

        .. seealso::

            :meth:`notify` for an asynchronous version of this method.
        """
        if not self.notifications:
            return

        cursor.execute(
            "SELECT pg_notify(%s, %s)",
            [
                f"{self.prefix}events",
                json_dumps({"t": event, **payload}),
            ],
        )

    async def cancel_job(self, ref: Reference):
        """
        Cancel a job by reference.

        Marks the job failed and invalidates its execution claim, preventing
        a late completion from overwriting the cancellation.

        This will attempt to cancel a job that is currently running, if it
        is possible to do so. Notifications must be enabled for this to work.

        :param ref: The reference to the job to cancel.
        """
        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
            conn.transaction(),
        ):
            await self.cancel_job_ex(cursor, ref)

            # Tell any workers that might have already snagged the job
            # to cancel it.
            await self.notify(cursor, "job.cancelled", {"j": ref.identifier})

    async def cancel_job_ex(
        self, cursor: AsyncCursor[DictRow], ref: Reference
    ) -> int:
        """
        Cancel a job by reference using an existing cursor.

        See :meth:`cancel_job` for more information.

        .. seealso::

            :meth:`cancel_job` for a helper that manages the connection,
            transaction, and emits notifications.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param ref: The reference to the job to cancel.
        :return: The number of rows updated (0 or 1).
        """
        await cursor.execute(
            sql.SQL(
                """
                UPDATE {jobs}
                SET state = 'failed', claim_id = NULL, completed_at = NOW()
                WHERE id = %s
                """
            ).format(jobs=sql.Identifier(f"{self.prefix}jobs")),
            [ref.identifier],
        )
        return cursor.rowcount or 0

    def _get_all_workers_sql(self):
        return sql.SQL(
            """
            SELECT
                wr.*,
                l.worker_id IS NOT NULL as is_leader
            FROM
                {workers} wr
            LEFT JOIN
                {leader} l on l.worker_id = wr.worker_id
            """
        ).format(
            workers=sql.Identifier(f"{self.prefix}workers"),
            leader=sql.Identifier(f"{self.prefix}leader"),
        )

    @_ensure_pool_is_open
    async def retry_jobs(self, refs: list[Reference]):
        """
        Retry one or more jobs by reference.

        This will make the referenced jobs eligible to be picked up again by
        workers by resetting transient execution fields and scheduling them
        immediately. Attempts are reset to 0 to permit re-execution even if the
        job had reached ``max_attempts``. Error history is preserved.

        Jobs currently in the ``running`` state are ignored.

        :param refs: The references to the jobs to retry.
        """
        if not refs:
            return

        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
            conn.transaction(),
        ):
            queues = await self.retry_jobs_ex(cursor, refs)
            if self.notifications and queues:
                for q in queues:
                    await self.notify(cursor, "queue.pushed", {"q": q})

    @_ensure_pool_is_open
    async def purge_jobs(self, refs: list[Reference]):
        """
        Permanently remove one or more jobs by reference.

        This will delete the job rows from the database. Use with care. It will
        not handle cancellation of running jobs; use :meth:`cancel_job` for
        that.

        :param refs: The references to the jobs to purge.
        """
        if not refs:
            return

        async with (
            self.pool.connection() as conn,
            conn.cursor(row_factory=dict_row) as cursor,
        ):
            await self.purge_jobs_ex(cursor, refs)

    async def retry_jobs_ex(
        self, cursor: AsyncCursor[DictRow], refs: list[Reference]
    ) -> set[str]:
        """
        Retry one or more jobs by reference using an existing cursor.

        See :meth:`retry_jobs` for more information.

        .. seealso::

            :meth:`retry_jobs` for a helper that manages the connection and
            emits notifications.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param refs: The references to the jobs to retry.
        :return: The set of affected queue names to assist callers in
            emitting notifications.
        """
        if not refs:
            return set()

        await cursor.execute(
            sql.SQL(
                """
                UPDATE {jobs} AS j
                SET
                    started_at = NULL,
                    completed_at = NULL,
                    taken_by = NULL,
                    claim_id = NULL,
                    scheduled_at = NOW(),
                    state = 'retrying',
                    attempts = 0
                WHERE j.id = ANY(%(ids)s)
                  AND j.state != 'running'
                RETURNING j.queue
                """
            ).format(jobs=sql.Identifier(f"{self.prefix}jobs")),
            {"ids": [ref.identifier for ref in refs]},
        )
        rows = await cursor.fetchall()
        return {row["queue"] for row in rows}

    async def purge_jobs_ex(
        self, cursor: AsyncCursor[DictRow], refs: list[Reference]
    ) -> int:
        """
        Permanently remove one or more jobs by reference using an existing
        cursor.

        See :meth:`purge_jobs` for more information.

        .. seealso::

            :meth:`purge_jobs` for a helper that manages the connection.

        :param cursor: The cursor to use for the operation. Must use a
            dict_row row factory.
        :param refs: The references to the jobs to purge.
        :return: The number of rows deleted.
        """
        if not refs:
            return 0

        await cursor.execute(
            sql.SQL(
                """
                DELETE FROM {jobs}
                WHERE id = ANY(%(ids)s)
                """
            ).format(jobs=sql.Identifier(f"{self.prefix}jobs")),
            {"ids": [ref.identifier for ref in refs]},
        )
        return cursor.rowcount or 0

    def _get_queue_sql(self):
        return sql.SQL(
            """
            SELECT
                *
            FROM
                {queues}
            WHERE
                name = %s
            """
        ).format(queues=sql.Identifier(f"{self.prefix}queues"))

    def _get_all_queues_sql(self):
        return sql.SQL(
            """
            SELECT
                *
            FROM
                {queues}
            """
        ).format(queues=sql.Identifier(f"{self.prefix}queues"))

    def _push_job_sql(self):
        return sql.SQL(
            """
            INSERT INTO
                {jobs} (
                    id,
                    queue,
                    func,
                    kwargs,
                    limits,
                    meta,
                    priority,
                    max_attempts,
                    scheduled_at,
                    unique_key
                )
            VALUES (
                %(id)s,
                %(queue)s,
                %(func)s,
                %(kwargs)s,
                %(limits)s,
                %(meta)s,
                %(priority)s,
                %(max_attempts)s,
                %(scheduled_at)s,
                %(unique_key)s
            )
            ON CONFLICT (unique_key)
            WHERE
                unique_key IS NOT NULL
                    AND state NOT IN ('succeeded', 'failed')
            DO UPDATE
               SET
                   state = {jobs}.state
            RETURNING id;
            """
        ).format(jobs=sql.Identifier(f"{self.prefix}jobs"))

    def _get_job_sql(self):
        return sql.SQL(
            """
            SELECT
                *
            FROM
                {jobs}
            WHERE
                id = %s
            """
        ).format(jobs=sql.Identifier(f"{self.prefix}jobs"))

    def _get_jobs_sql(self):
        return sql.SQL(
            """
            SELECT
                *
            FROM
                {jobs}
            WHERE
                id = ANY(%s)
            """
        ).format(jobs=sql.Identifier(f"{self.prefix}jobs"))

    def _declare_sql(self, upsert: bool):
        action = sql.SQL(
            """
            UPDATE SET
                name = EXCLUDED.name
            """
        )
        if upsert:
            action = sql.SQL(
                """
                UPDATE SET
                    state = EXCLUDED.state,
                    concurrency = EXCLUDED.concurrency,
                    tags = EXCLUDED.tags,
                    executor = EXCLUDED.executor,
                    executor_options = EXCLUDED.executor_options,
                    polling_interval = EXCLUDED.polling_interval,
                    rate_limit = EXCLUDED.rate_limit,
                    rate_limit_window = EXCLUDED.rate_limit_window,
                    resume_at = EXCLUDED.resume_at,
                    eager_polling = EXCLUDED.eager_polling
                """
            )

        return sql.SQL(
            """
            INSERT INTO {queues} (
                name,
                state,
                concurrency,
                tags,
                executor,
                executor_options,
                polling_interval,
                rate_limit,
                rate_limit_window,
                resume_at,
                eager_polling
            ) VALUES (
                %(name)s,
                %(state)s,
                %(concurrency)s,
                %(tags)s,
                %(executor)s,
                %(executor_options)s,
                %(polling_interval)s,
                %(rate_limit)s,
                %(rate_limit_window)s,
                %(resume_at)s,
                %(eager_polling)s
            )
            ON CONFLICT (name) DO
                {action}
            RETURNING 
                state,
                concurrency,
                tags,
                polling_interval,
                executor,
                executor_options,
                rate_limit,
                rate_limit_window,
                resume_at,
                eager_polling
            """
        ).format(
            queues=sql.Identifier(f"{self.prefix}queues"),
            action=action,
        )

    @staticmethod
    def _in_lock_order(
        jobs: list[Job | IsAJob[..., Any]],
    ) -> list[tuple[int, Job | IsAJob[..., Any]]]:
        """
        Pair each job with its original index and order the pairs by
        unique_key, which is the order in which row locks must be acquired.

        Jobs without a unique_key never conflict with an existing row, so
        their relative order does not matter and they are grouped first.
        """
        return sorted(
            enumerate(jobs),
            key=lambda pair: lock_order_key(
                (
                    pair[1] if isinstance(pair[1], Job) else pair[1].job
                ).unique_key
            ),
        )

    @staticmethod
    def _get_job_params(job: Job | IsAJob[..., Any]) -> dict:
        """
        Get the parameters for a job to be inserted into the database.

        :param job: The job to get parameters for.
        :return: A dictionary of parameters for the job.
        """
        if callable(job):
            job = job.job

        return {
            "id": chancy_uuid(),
            "queue": job.queue,
            "func": job.func,
            "kwargs": Json(job.kwargs or {}),
            "limits": Json([limit.serialize() for limit in job.limits]),
            "meta": Json(job.meta),
            "priority": job.priority,
            "max_attempts": job.max_attempts,
            "scheduled_at": job.scheduled_at,
            "unique_key": job.unique_key,
        }


from chancy.plugins.leadership import Leadership
from chancy.plugins.metrics import Metrics
from chancy.plugins.pruner import Pruner
from chancy.plugins.recovery import Recovery
from chancy.plugins.workflow import WorkflowPlugin
