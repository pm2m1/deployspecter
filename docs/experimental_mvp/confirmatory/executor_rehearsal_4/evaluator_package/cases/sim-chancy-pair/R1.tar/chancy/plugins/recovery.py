from psycopg import AsyncCursor, sql
from psycopg.rows import DictRow, dict_row

from chancy.app import Chancy
from chancy.plugin import Plugin
from chancy.utils import timed_block
from chancy.worker import Worker


class Recovery(Plugin):
    """
    Recovers jobs that appear to be abandoned by a worker.

    .. note::
        This plugin is enabled by default, you only need to provide it in the
        list of plugins to customize its arguments or if ``no_default_plugins``
        is set to ``True``.

    .. code-block:: python

        from chancy.plugins.recovery import Recovery

        async with Chancy(..., plugins=[
            Recovery()
        ]) as chancy:
            ...

    Typically, this happens when a worker is unexpectedly terminated, or has
    otherwise been lost which we recognize by checking the last seen timestamp
    of the worker heartbeat.

    This will transition any matching jobs back to the "pending" state, and
    increment the `max_attempts` counter by 1 to allow it to be retried.

    Recovery invalidates the old execution's claim and requests best-effort
    cancellation of that execution. It does not wait for acknowledgement:
    the old worker may be unreachable, and cancellation may be unsupported.
    Late updates from the old claim are discarded even if it keeps running.

    :param poll_interval: The number of seconds between recovery poll intervals.
    """

    def __init__(self, *, poll_interval: int = 60):
        super().__init__()
        self.poll_interval = poll_interval

    @staticmethod
    def get_identifier() -> str:
        return "chancy.recovery"

    @staticmethod
    def get_dependencies() -> list[str]:
        return ["chancy.leadership"]

    async def run(self, worker: Worker, chancy: Chancy):
        while await self.sleep(self.poll_interval):
            await self.wait_for_leader(worker)
            async with (
                chancy.pool.connection() as conn,
                conn.cursor(row_factory=dict_row) as cursor,
            ):
                with timed_block() as chancy_time:
                    rows_recovered = await self.recover(worker, chancy, cursor)
                    chancy.log.info(
                        f"Recovery recovered {rows_recovered} row(s) from"
                        f" the database. Took {chancy_time.elapsed:.2f}"
                        f" seconds."
                    )
                    await chancy.notify(
                        cursor,
                        "recovery.recovered",
                        {
                            "elapsed": chancy_time.elapsed,
                            "rows_recovered": rows_recovered,
                        },
                    )

    @classmethod
    async def recover(
        cls, worker: Worker, chancy: Chancy, cursor: AsyncCursor[DictRow]
    ) -> int:
        """
        Recover jobs that were running when the worker was unexpectedly
        terminated, or has otherwise been lost.

        :param worker: The worker that is running the recovery.
        :param chancy: The Chancy application.
        :param cursor: The cursor to use for database operations.
        :return: The number of rows recovered from the database
        """
        query = sql.SQL(
            """
            WITH abandoned AS (
                SELECT cj.id, cj.claim_id
                FROM {jobs} cj
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM {workers} cw
                    WHERE cw.worker_id = cj.taken_by
                      AND cw.last_seen >= NOW() - INTERVAL '{interval} SECOND'
                )
                AND cj.state = 'running'
                FOR UPDATE OF cj SKIP LOCKED
            )
            UPDATE {jobs} cj
            SET
                state = 'pending',
                taken_by = NULL,
                claim_id = NULL,
                started_at = NULL,
                max_attempts = max_attempts + 1
            FROM abandoned
            WHERE cj.id = abandoned.id
            RETURNING cj.id, abandoned.claim_id;
            """
        ).format(
            jobs=sql.Identifier(f"{chancy.prefix}jobs"),
            workers=sql.Identifier(f"{chancy.prefix}workers"),
            interval=sql.Literal(worker.heartbeat_timeout),
        )

        await cursor.execute(query)
        recovered = await cursor.fetchall()
        await chancy.notify_many(
            cursor,
            (
                (
                    "job.recovered",
                    {"j": str(row["id"]), "c": str(row["claim_id"])},
                )
                for row in recovered
                if row["claim_id"] is not None
            ),
        )
        return len(recovered)
