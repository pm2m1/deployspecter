import asyncio
from asyncio import CancelledError

from chancy import Reference
from chancy.executors.base import Executor
from chancy.job import Limit, QueuedJob


class AsyncExecutor(Executor):
    """
    An Executor which uses asyncio to run its jobs in the main event loop.

    This executor is useful for running large numbers of IO-bound jobs, as it
    can run many jobs concurrently without blocking the main event loop and
    without the high overhead of new processes or threads. However, it is not
    suitable for CPU-bound jobs, as it will block the main event loop and
    prevent other jobs & queues from running.

    To use this executor, simply pass the import path to this class in the
    ``executor`` field of your queue configuration or use the
    :class:`~chancy.app.Chancy.Executor` shortcut:

    .. code-block:: python

        async with Chancy("postgresql://localhost/postgres") as chancy:
            await chancy.declare(
                Queue(
                    name="default",
                    executor=Chancy.Executor.Async,
                )
            )
    """

    capabilities = (
        Executor.Capability.ASYNC_JOBS
        | Executor.Capability.CANCELLATION
        | Executor.Capability.AUTOMATIC_TIME_LIMITS
    )

    def __init__(self, worker, queue):
        super().__init__(worker, queue)
        self.jobs: dict[asyncio.Task, QueuedJob] = {}

    async def push(self, job: QueuedJob):
        job = await self.on_job_starting(job)
        task = asyncio.create_task(self._job_wrapper(job))
        self.jobs[task] = job
        task.add_done_callback(self.jobs.pop)

    def __len__(self):
        return len(self.jobs)

    async def _job_wrapper(self, job: QueuedJob):
        try:
            job, func, kwargs = self.prepare_job_for_execution(job)
            timeout = self.get_limit(job, Limit.Type.TIME)

            async with asyncio.timeout(timeout):
                result = await func(**kwargs)
            await self.on_job_completed(job=job, result=result)
        # User jobs may raise any exception; this boundary records the failure.
        except (Exception, CancelledError) as exc:  # noqa: BLE001
            await self.on_job_completed(job=job, exc=exc, result=None)

    async def cancel(self, ref: Reference):
        for job in self.get_running_jobs():
            if job.id == ref.identifier:
                await self.cancel_execution(job)

    async def cancel_execution(self, job: QueuedJob):
        for task, running in self.jobs.items():
            if running.id == job.id and running.claim_id == job.claim_id:
                task.cancel()
                return

    def get_running_jobs(self) -> list["QueuedJob"]:
        return list(self.jobs.values())

    def _cancel_jobs(self) -> list[asyncio.Task]:
        tasks = list(self.jobs)
        for task in tasks:
            task.cancel()
        return tasks

    async def stop(self):
        """
        Stop the executor, giving it a chance to clean up any resources it
        may have allocated to running jobs.
        """
        await asyncio.gather(
            *self._cancel_jobs(),
            return_exceptions=True,
        )

    async def _stop_on_cancel(self):
        self._cancel_jobs()

    def get_default_concurrency(self):
        """
        Get the default concurrency level for this executor.

        This method is called when the queue's concurrency level is set to
        None. It should return the number of jobs that can be processed
        concurrently by this executor.

        By default, returns 100.
        """
        return 100
